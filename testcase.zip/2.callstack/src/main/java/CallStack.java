public class CallStack {
    public static void main(String[] args) {
        Foo foo = new Foo();
        foo.testFoo(10);
    }
}