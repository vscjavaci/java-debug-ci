public interface  IFoo {
    void sayHello();
}
