public class Foo implements IFoo {
    public void sayHello() {
        System.out.println("hello world! (version one)");
    }
}